import os
import pathlib
import shutil

import tensorflow as tf
import tensorflow_model_analysis as tfma
import tfx
from tfx.components import (ImportExampleGen,
                            StatisticsGen, SchemaGen, ExampleValidator,
                            Transform, Trainer, Evaluator, Pusher)
from tfx.orchestration.experimental.interactive.interactive_context import InteractiveContext
from tfx.proto import pusher_pb2
from tfx.types import Channel
from tfx.types.standard_artifacts import Model, ModelBlessing
from tfx.v1.dsl import Resolver
from tfx.v1.dsl.experimental import LatestBlessedModelStrategy


def copy_artifact(component, root_dir):
    for key, output in component.outputs.items():
        src = output.get()[0].uri
        dest = pathlib.Path(os.path.join(root_dir, key))
        shutil.copytree(src, dest)


# Pipeline 관리자
context = InteractiveContext()
artifact_dir = pathlib.Path("artifacts")

# 1. 데이터셋 로드
# 파이프라인 외부에서 들어올 tfrecord 파일: 이 스크립트와 같은 디렉토리 아래,
# "data/complaints/records/{dataset}.tfrecord" 경로가 존재해야 한다.
record_dir = "data/complaints/records"
if not os.path.exists(record_dir):
    raise FileNotFoundError("Not found record files.")
else:
    print(os.listdir(record_dir))
    print("Record files found. Continue process to the next.")

example_gen = ImportExampleGen(input_base=record_dir)
context.run(example_gen)
examples = example_gen.outputs["examples"]
print(f"### {examples.get()}")

copy_artifact(example_gen, artifact_dir)
print("Example output artifact created.")

# 2. 데이터셋 통계치 산출
statistics_gen = StatisticsGen(examples=examples)
context.run(statistics_gen)
stats = statistics_gen.outputs["statistics"]
copy_artifact(statistics_gen, artifact_dir)
print("Statistics output artifact created.")

# 3. 데이터셋 스키마 산출
schema_gen = SchemaGen(statistics=stats, infer_feature_shape=True)
context.run(schema_gen)
schema = schema_gen.outputs["schema"]
copy_artifact(schema_gen, artifact_dir)
print("Schema output artifact created.")

# 4. 데이터셋 검증
example_validator = ExampleValidator(statistics=stats, schema=schema)
context.run(example_validator)
anomalies = example_validator.outputs["anomalies"]
copy_artifact(example_validator, artifact_dir)
print("Anomalies output artifact created.")

# 5. 데이터셋 변환
transform = Transform(examples=examples, schema=schema, module_file="transform_module.py")
context.run(transform)
transform_graph = transform.outputs["transform_graph"]
transformed_examples = transform.outputs["transformed_examples"]
copy_artifact(transform, artifact_dir)
print("Transform output artifact created.")

# 6. 모델 훈련
trainer = Trainer(examples=transformed_examples,
                  transform_graph=transform_graph,
                  schema=schema, module_file="trainer_module.py",
                  train_args=tfx.proto.trainer_pb2.TrainArgs(num_steps=50),
                  eval_args=tfx.proto.trainer_pb2.EvalArgs(num_steps=10))
context.run(trainer)
trained_model = trainer.outputs["model"]
copy_artifact(trainer, artifact_dir)
print("Trainer output artifact created.")

# 7. baseline-incoming 모델 중 결정자 선언
model_resolver = Resolver(
    strategy_class=LatestBlessedModelStrategy,
    model=Channel(type=Model),
    model_blessing=Channel(type=ModelBlessing)
).with_id("latest_blessed_model_resolver")
context.run(model_resolver)
copy_artifact(model_resolver, artifact_dir)
print("Resolver output artifact created.")

# 8. 모델 간 평가
eval_config = tfma.EvalConfig(
    model_specs=[tfma.ModelSpec(label_key="consumer_disputed")],
    slicing_specs=[tfma.SlicingSpec(), tfma.SlicingSpec(feature_keys=["product"])],
    metrics_specs=[
        tfma.MetricsSpec(
            metrics=[
                tfma.MetricConfig(class_name="BinaryAccuracy"),
                tfma.MetricConfig(class_name="ExampleCount"),
                tfma.MetricConfig(class_name="AUC")],
            # baseline 모델과 비교해 우위에 있더라도 아래 임계치를 넘어야 bless를 받는다.
            thresholds={
                "AUC": tfma.MetricThreshold(
                    value_threshold=tfma.GenericValueThreshold(
                        lower_bound={"value": 0.65}),
                    # 두 모델 간 지표 ∆가 0.01은 넘어야 하고, 새 모델 지표값은 클수록 좋다는 의미.
                    change_threshold=tfma.GenericChangeThreshold(
                        direction=tfma.MetricDirection.HIGHER_IS_BETTER,
                        absolute={"value": 0.01}))})])

evaluator = Evaluator(
    examples=examples,
    model=trained_model,
    baseline_model=model_resolver.outputs["model"],
    eval_config=eval_config)
context.run(evaluator)
copy_artifact(evaluator, artifact_dir)
print("Evaluator output artifact created.")

# Load the evaluation results.
blessing = evaluator.outputs["blessing"]
output_path = evaluator.outputs["evaluation"].get()[0].uri
tfma_result = tfma.load_eval_result(output_path)
validation_result = tfma.load_validation_result(output_path)

# 9. blessed 모델 내보내기
_serving_model_dir = "serving_model_dir"
pusher = Pusher(model=trained_model,
                model_blessing=blessing,
                push_destination=pusher_pb2.PushDestination(
                    filesystem=pusher_pb2.PushDestination.Filesystem(
                        base_directory=_serving_model_dir)))
context.run(pusher)
copy_artifact(pusher, artifact_dir)
print("Pusher output artifact created.")
